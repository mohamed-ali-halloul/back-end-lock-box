module.exports = {
    secret: "lockbox-secret-key"
  };