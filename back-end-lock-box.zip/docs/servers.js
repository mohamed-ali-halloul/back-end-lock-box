module.exports = {
    servers: [
      {
        url: "http://localhost:3001/api", 
        description: "Local server", 
      },
    ],
  };